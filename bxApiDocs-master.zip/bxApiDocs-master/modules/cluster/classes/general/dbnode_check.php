<?
class CAllClusterDBNodeCheck
{
	public static function MainNode()
	{
		return array();
	}
}
?>