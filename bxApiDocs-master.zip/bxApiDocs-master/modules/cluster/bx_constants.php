<?
/**
 * BX_MEMCACHE_CLUSTER
 */
define('BX_MEMCACHE_CLUSTER', "'.EscapePHPString(CMain::GetServerUniqID()).'");

/**
 * CACHED_b_cluster_dbnode
 */
define('CACHED_b_cluster_dbnode', 3600);

/**
 * ADMIN_MODULE_NAME
 */
define('ADMIN_MODULE_NAME', "cluster");


?>