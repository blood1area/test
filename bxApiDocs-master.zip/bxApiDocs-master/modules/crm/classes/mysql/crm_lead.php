<?php
IncludeModuleLangFile(__FILE__);

class CCrmLead extends CAllCrmLead
{
    const TABLE_NAME = 'b_crm_lead';
    const DB_TYPE = 'MYSQL';
}
