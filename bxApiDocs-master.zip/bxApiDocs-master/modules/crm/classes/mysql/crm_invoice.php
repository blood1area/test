<?php
IncludeModuleLangFile(__FILE__);

class CCrmInvoice extends CAllCrmInvoice
{
	const DB_TYPE = 'MYSQL';
}
