<?php
IncludeModuleLangFile(__FILE__);

class CCrmContact extends CAllCrmContact
{
    const TABLE_NAME = 'b_crm_contact';
    const DB_TYPE = 'MYSQL';
}
