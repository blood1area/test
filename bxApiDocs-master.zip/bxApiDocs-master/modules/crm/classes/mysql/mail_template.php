<?php
class CCrmMailTemplate extends CAllCrmMailTemplate
{
	const TABLE_NAME = 'b_crm_usr_mt';
	const DB_TYPE = 'MYSQL';
}