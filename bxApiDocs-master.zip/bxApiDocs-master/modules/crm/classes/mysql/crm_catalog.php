<?php
IncludeModuleLangFile(__FILE__);

/*
 * CRM Product Catalogue.
 * It is based on IBlock module.
 * */
class CCrmCatalog extends CAllCrmCatalog
{
	const TABLE_NAME = 'b_crm_catalog';
	const DB_TYPE = 'MYSQL';
}
