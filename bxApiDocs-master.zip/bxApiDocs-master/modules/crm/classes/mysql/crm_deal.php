<?php
IncludeModuleLangFile(__FILE__);

class CCrmDeal extends CAllCrmDeal
{
    const TABLE_NAME = 'b_crm_deal';
    const DB_TYPE = 'MYSQL';
}
