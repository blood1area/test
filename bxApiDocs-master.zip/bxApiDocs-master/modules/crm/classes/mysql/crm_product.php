<?php
IncludeModuleLangFile(__FILE__);

/*
 * CRM Product.
 * It is based on IBlock module.
 * */
class CCrmProduct extends CAllCrmProduct
{
	const TABLE_NAME = 'b_crm_product';
	const DB_TYPE = 'MYSQL';
}
