<?php
IncludeModuleLangFile(__FILE__);

class CCrmCompany extends CAllCrmCompany
{
    const TABLE_NAME = 'b_crm_company';
    const DB_TYPE = 'MYSQL';
}
