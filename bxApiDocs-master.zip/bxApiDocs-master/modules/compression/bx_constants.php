<?
/**
 * BX_COMPRESSION_DISABLED
 */
define('BX_COMPRESSION_DISABLED', true);

/**
 * BX_SPACES_DISABLED
 */
define('BX_SPACES_DISABLED', true);


?>