<?
// define("ADMIN_MODULE_NAME", "advertising");
?>