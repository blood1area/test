<?
/**
 * CACHED_b_bitrixcloud_option
 */
define('CACHED_b_bitrixcloud_option', 36000);


?>