<?
// define("ADMIN_MODULE_NAME", "bizproc");
?>