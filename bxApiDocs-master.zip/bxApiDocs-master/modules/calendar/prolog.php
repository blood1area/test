<?
// define("ADMIN_MODULE_NAME", "calendar");
IncludeModuleLangFile(__FILE__);
?>