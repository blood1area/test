<?
/**
 * ADMIN_MODULE_NAME
 */
define('ADMIN_MODULE_NAME', "calendar");


?>