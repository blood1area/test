<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/general/store_docs_type.php");

class CCatalogArrivalDocs extends CAllCatalogArrivalDocsType
{

}

class CCatalogMovingDocs extends CAllCatalogMovingDocsType
{

}

class CCatalogReturnsDocs extends CAllCatalogReturnsDocsType
{

}

class CCatalogDeductDocs extends CAllCatalogDeductDocsType
{

}

class CCatalogUnReservedDocs extends CAllCatalogUnReservedDocsType
{

}