<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/general/catalog_load.php");

class CCatalogLoad extends CAllCatalogLoad
{
}
?>