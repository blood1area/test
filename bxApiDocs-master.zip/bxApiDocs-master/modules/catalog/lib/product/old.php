<?php
namespace Bitrix\Catalog;

use Bitrix\Catalog\Product;

/**
 * @deprecated deprecated since catalog 16.5.3
 * @see \Bitrix\Catalog\Product\Search
 *
 * Class SearchHandlers
 * @package Bitrix\Catalog
 */
class SearchHandlers extends Product\Search
{

}